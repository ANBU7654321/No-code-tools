from django.contrib import admin
from .models import Pages
# Register your models here.

admin.site.register(Pages)
